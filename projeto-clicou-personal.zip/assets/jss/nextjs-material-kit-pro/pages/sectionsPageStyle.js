import { main } from "assets/jss/nextjs-material-kit-pro.js";

const sectionsPageStyle = {
  main: {
    ...main
  }
};

export default sectionsPageStyle;
